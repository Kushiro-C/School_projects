#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "my_cat.h"
#include "tar.h"

int main(int argc, char const *argv[])
{
    char str[BLOCKSIZE];
    if(argc == 1) {
        int r;
        int w;
        while((r = read(STDIN_FILENO, str, BLOCKSIZE)) > 0) {
            if((w = write(STDOUT_FILENO, str, r)) < 0)
                return -1;
        }
    } else if (argc > 1) {

    }
    return 0;
}
